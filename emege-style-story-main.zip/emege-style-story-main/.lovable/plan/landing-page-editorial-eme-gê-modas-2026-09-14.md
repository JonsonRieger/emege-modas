# Landing page editorial Eme gê modas

## Objetivo
Criar na página inicial uma experiência cinematográfica, feminina e altamente conversiva, conduzindo visitantes da descoberta da marca até conversas no WhatsApp e visitas à loja.

## Direção visual
- Campanha editorial contemporânea em blush, off-white, ameixa suave e dourado pontual.
- Headings serifados elegantes combinados com sans-serif limpa.
- Composições assimétricas, fotografia em grande escala, respiro amplo, bordas finas e movimento sutil.
- Mobile terá composição própria, oferta e WhatsApp sempre acessíveis, com animações reduzidas.

## Estrutura e conteúdo
- Abertura imersiva com conceito central, duas ações, oferta de 20% e indicador de rolagem.
- Transição de assinatura e narrativa visual da experiência física da loja.
- Atendimento humano e universo Eme gê em mosaicos editoriais, com destaque para feminino e infantil.
- Bloco forte de moda feminina, blusinhas, preço a partir de R$ 59,90 e marcas informadas.
- Condicional em quatro etapas, Grupo VIP, história da marca e espaços reservados com elegância para provas reais.
- Encerramento comercial com oferta, endereço, Instagram e WhatsApp.

## Interações e conversão
- Todos os CTAs de conversa abrirão o WhatsApp da loja com mensagens contextuais pré-preenchidas.
- Botão flutuante permanente, barra discreta de progresso e navegação mínima.
- Revelações no scroll, movimentos editoriais leves, zoom sutil e feedback de clique, respeitando redução de movimento.

## Assets e veracidade
- Nenhum arquivo da loja está disponível no projeto neste momento. Não serão inventados logo oficial, clientes, depoimentos ou avaliações.
- Para manter a experiência visual completa, serão criadas imagens editoriais conceituais coerentes com a marca, claramente usadas como ambientação de campanha, e uma assinatura tipográfica temporária “Eme gê modas”.
- Áreas de prova social serão estruturadas sem depoimentos falsos e poderão receber os materiais reais depois.

## Técnica
- Implementação exclusivamente front-end na página inicial.
- Design system centralizado com tokens semânticos, componentes de ação existentes e metadados próprios da página.
- Verificação visual em desktop e mobile, além de checagem dos links e estados interativos.
